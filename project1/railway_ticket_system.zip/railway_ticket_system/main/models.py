from django.db import models
from users.models import Passenger
from django.forms import ModelForm

class Station(models.Model):
	staion_name = models.CharField(max_length=50, primary_key=True)
	def __str__(self):
		return self.staion_name


class Train(models.Model):
	train_name = models.CharField(max_length=50, primary_key=True)
	total_seat = models.IntegerField(null=True)
	def __str__(self):
		return self.train_name

class schedule(models.Model):
	train_name = models.ForeignKey(Train, on_delete=models.CASCADE)
	station_name = models.ForeignKey(Station, on_delete=models.CASCADE)
	time = models.TimeField(null=True)


class TicketPrice(models.Model):
	train = models.ForeignKey(Train, on_delete=models.CASCADE)
	sourceStation = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='source')
	destStation = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='dst')
	price = models.IntegerField(null=True)


class Booking(models.Model):
	sourceStation = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='bookingsrc')
	train = models.OneToOneField(Train, on_delete=models.CASCADE)
	destStation = models.ForeignKey(Station, on_delete=models.CASCADE, related_name = 'bookingdst')
	passenger = models.OneToOneField(Passenger, on_delete=models.CASCADE)
	date = models.DateField(null=True)
	time = models.TimeField(null=True)

class Booking(ModelForm):
	class Meta:
		model = Booking
		fields= ['sourceStation']



