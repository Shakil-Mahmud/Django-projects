from django.urls import path
from . import views

urlpatterns = [
	path('',views.home, name='home'),
	path('schedule/',views.scheduleview, name='schedule'),
	#path('show_schedule/',views.show_schedule, name='show_schedule'),
	path('booking/',views.booking, name='booking'),
	path('ticketprice/',views.ticketprice , name='ticket_price')	
]