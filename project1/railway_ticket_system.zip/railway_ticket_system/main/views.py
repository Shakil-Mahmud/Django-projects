from django.shortcuts import render
from django.http import HttpResponse
from .forms import TicketPriceForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Train
from .models import schedule
from .forms import BookingForm


def home(request):
	return render(request, 'main/home.html')

def scheduleview(request):
	q = Train.objects.all()
	if request.method == 'POST':
		src = request.POST.get('source')
		st = schedule.objects.all()	
		contex = {
			'train_name' : q,
			'flage' : True,
			'stations': st,
		}
	else:
		contex = {
			'train_name' : q,
			'flage' : False
		}
	return render(request, 'main/schedule.html', contex)

def booking(request):
	if request.method== 'POST':
		form = BookingForm(request.POST)
		if form.is_valid() :
			form.save()
			messages.success(request, f'Booking confirmed')
			return redirect('home')
	else:
		form = BookingForm()
	return render(request, 'users/booking.html', {'form' : form})

'''def show_schedule(request):
	print('OK')
	if request.method == 'POST':
		src = request.POST.get('source')
		print(src)
	return render(request, 'main/schedule.html')		'''

def ticketprice(request):
	if request.method == 'POST':
		form = TicketPriceForm(request.POST)
		if form.is_valid() :
			#form.save();
			train = form.POST.get('train')
			sourceStation = form.POST.get('sourceStation')
			destStation = form.POST.get('destStation')
			messages.success(request, f'Searching ')
			return redirect('login')

	else:
		form = TicketPriceForm(request)
	return render(request, 'main/price.html', {'form': form})


@login_required
def booking(request):
	return render(request, 'main/booking.html')